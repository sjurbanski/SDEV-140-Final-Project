""" 

Author: Scott Urbanski
Date Written: 07/12/24
Assignment: Modulus Sound Machine
Description: In this program the user is able to select a musical
             instrument from a group of radio buttons. The user can then
             press the record button which outputs the instrument choice
             to a text file. Finally, the user can press keys on a numpad
             which will output a numerical midi value to the text file.

"""

from tkinter import *
from breezypythongui import EasyFrame
import os

class ModulusSoundMachine(EasyFrame):

    def __init__(self):

        # initializing a notes variable for all the notes the user enters
        self.notes = []

        # initializing the main window, setting a title, and setting the background color   
        EasyFrame.__init__(self, width=250, height=200)
        self.setTitle("Modulus Sound Machine")
        self.setBackground("Light Gray")

        # creating icon (labels) for each of the instruments
        guitarLabel = self.addLabel(text="", row=2, column=0, sticky="N")
        guitarLabel["text"] = "Guitar"
        pianoLabel = self.addLabel(text="", row=1, column=0, sticky="N")
        pianoLabel["text"] = "Piano"
        trumpetLabel = self.addLabel(text="", row=3, column=0, sticky="N")
        trumpetLabel["text"] = "Trumpet"
        cowbellLabel = self.addLabel(text="", row=4, column=0, sticky="N")
        cowbellLabel["text"] = "Cowbell"

        # there were difficulties loading images so the absolute path was needed
        # it will not work on another PC, so the images are placed in a try statement to prevent crashing
        try:
            self.guitarImage = PhotoImage(file="C:\\Users\\Scott\\Documents\\SDEV_140\\ModulusSoundMachine\\Guitar.gif")
            guitarLabel["image"] = self.guitarImage
            self.pianoImage = PhotoImage(file="C:\\Users\\Scott\\Documents\\SDEV_140\\ModulusSoundMachine\\Piano.gif")
            pianoLabel["image"] = self.pianoImage
            self.trumpetImage = PhotoImage(file="C:\\Users\\Scott\\Documents\\SDEV_140\\ModulusSoundMachine\\Trumpet.gif")
            trumpetLabel["image"] = self.trumpetImage
            self.cowbellImage = PhotoImage(file="C:\\Users\\Scott\\Documents\\SDEV_140\\ModulusSoundMachine\\Cowbell.gif")
            cowbellLabel["image"] = self.cowbellImage 
        except:
            pass

        # creating a heading, a group of radio buttons, and setting Piano as the default radio button
        self.addLabel(text="Soundwaves", row=0,column=1, sticky="WE", background="Light Gray")
        self.group = self.addRadiobuttonGroup(row=1,column=1,rowspan=4)
        defaultRB = self.group.addRadiobutton(text="Piano")
        self.group.setSelectedButton(defaultRB)
        self.group.addRadiobutton(text="Guitar")
        self.group.addRadiobutton(text="Trumpet")
        self.group.addRadiobutton(text="Cowbell")

        # creating the octave label and textbox
        self.addLabel(text="Octave", row=0, column=2, sticky="WE", background="Light Gray")
        self.octave = self.addIntegerField(row=1, column = 2, value=0, sticky="WEN")

        # creating a button panel with Record, Stop Recording, and Quit
        buttonPanel = self.addPanel(row=5, column=0, columnspan= 5, background="gray")
        self.record = buttonPanel.addButton(text="Record", row=5,column=0, command=self.Record)
        self.stopRecording = buttonPanel.addButton(text="Stop Recording", row=5, column=1, state="disabled", command=self.StopRecording)
        buttonPanel.addButton(text="Quit", row=5,column=2, command=lambda: quit(None))
        
        # opening up a second window for the numpad, setting its background color, title, geometry, and resizability
        keys = Toplevel()
        keys.config(bg="black")
        keys.title("Num Pad")
        keys.geometry("260x390")
        keys.resizable(False,False)

        # creating each button on the numpad
        modulus = Label(keys, text="MODULUS", font=("Calibri", "20", "bold italic"), fg="white", bg="black")
        modulus.pack(side="top")
        buttons = Frame(keys, background="black", width=260)
        buttons.pack(side="bottom")
        numLock = Button(buttons, text="Num\nLock", width=4, height=2, command=lambda: self.AddNote(10))
        numLock.grid(row=0, column=0)
        slash = Button(buttons, text="/" , width=4, height=2, command=lambda: self.AddNote(11))
        slash.grid(row=0, column=1)
        star = Button(buttons, text="*", width=4, height=2, command=lambda: self.AddNote(12))
        star.grid(row=0, column=2)
        minus = Button(buttons, text="-", width=4, height=2, command=self.DecreaseOctave)
        minus.grid(row=0, column=3)
        seven = Button(buttons, text="7", width=4, height=2, command=lambda: self.AddNote(7))
        seven.grid(row=1, column=0)
        eight = Button(buttons, text="8", width=4, height=2, command=lambda: self.AddNote(8))
        eight.grid(row=1, column=1)
        nine = Button(buttons, text="9", width=4, height=2, command=lambda: self.AddNote(9))
        nine.grid(row=1, column=2)
        four = Button(buttons, text="4", width=4, height=2, command=lambda: self.AddNote(4))
        four.grid(row=2, column=0)
        five = Button(buttons, text="5", width=4, height=2, command=lambda: self.AddNote(5))
        five.grid(row=2, column=1)
        six = Button(buttons, text="6", width=4, height=2, command=lambda: self.AddNote(6))
        six.grid(row=2, column=2)
        one = Button(buttons, text="1", width=4, height=2, command=lambda: self.AddNote(1))
        one.grid(row=3, column=0)
        two = Button(buttons, text="2", width=4, height=2, command=lambda: self.AddNote(2))
        two.grid(row=3, column=1)
        three = Button(buttons, text="3", width=4, height=2, command=lambda: self.AddNote(3))
        three.grid(row=3, column=2)
        plus = Button(buttons, text="+", width=4, height=4, command=self.IncreaseOctave)
        plus.grid(row=1, column=3, rowspan=2)
        zero = Button(buttons, text="0", width=8, height=2)
        zero.grid(row=4, column=0, columnspan=2)
        period = Button(buttons, text=".", width=4, height=2, command=self.DeleteNote)
        period.grid(row=4, column=2)
        enter = Button(buttons, text="Enter", width=4, height=4)
        enter.grid(row=3, column=3, rowspan=2)

        # determining the number of rows and columns on the numpad
        gridsize = buttons.grid_size()
        numberOfRows = gridsize[0]
        numberOfColumns = gridsize[1]

        # going through each row and column of the numpad and applying padding
        for row in range(numberOfRows+1):
            buttons.grid_rowconfigure(row, pad=20)
        for column in range(numberOfColumns+1):
            buttons.grid_columnconfigure(column, pad=20)


    def ValidOctave(self):
        """
        Checks to make sure the user has entered an appropriate octave value

        Parameters:
        self (object): the instance of the GUI program

        Returns:
        None
        """

        # checking to make sure the user has not changed the integer value to a garbage value
        try:
            # the octave value must be between 0 and 7
            if self.octave.getNumber() < 0:
                self.messageBox(title="ERROR", message="Octave must be between 0 and 7")
            if self.octave.getNumber() > 7:
                self.messageBox(title="ERROR", message="Octave must be between 0 and 7")
        except:
            self.messageBox(title="ERROR", message="Octave must be between 0 and 7")


    def AddNote(self, number):
        """
        Adds a midi note to the array

        Parameters:
        self (object): the instance of the GUI program
        number (int): a number ranging from 1 to 12 representing each of
                      the keys on one octave of a keyboard

        Returns:
        None
        """

        # checking to make sure the user has actually started recording
        if self.record["state"] == "disabled":
            # giving the user an error message if he or she has entered an invalid octave
            self.ValidOctave()
            # an issue occurred trying to get the ValidOctave method to return a true or false value
            # thus it is needed again here to add in the note to the text file if the octave is indeed valid
            try:
                if self.octave.getNumber() >= 0:
                    if self.octave.getNumber() <= 7:
                        self.notes.append(number + (self.octave.getNumber()*12))
            except:
                pass
    
    def DeleteNote(self):
        """
        Deletes a midi note from the array

        Parameters:
        self (object): the instance of the GUI program

        Returns:
        None
        """

        # checks to make sure that the user has started recording
        if self.record["state"] == "disabled":
            # if there are notes in the array, delete the last one
            if len(self.notes) > 0:
                self.notes.pop(len(self.notes)-1)
            # otherwise, tell the user that there aren't any notes to delete
            else:
                self.messageBox(title="INFO", message="No more notes to delete")


    def Record(self):
        """
        Opens up a text file and allows the user to start writing to the text file

        Parameters:
        self (object): the instance of the GUI program

        Returns:
        None
        """

        # opens up a text file and sets the text to null; also clears the notes array
        self.file = open("Desktop\\midiNotes.txt", 'w')
        self.notes.clear()
        self.text = ""

        # adding the instrument choice to the text file
        self.file.write(self.group.getSelectedButton()['text'])

        # disabling the record button
        self.record["state"] = "disabled"
        # enabling the stop recording button
        self.stopRecording["state"] = "normal"

    def StopRecording(self):
        """
        Appends the user's input to the text file and closes it

        Parameters:
        self (object): the instance of the GUI program

        Returns:
        None
        """

        # going through each note in the array and adding it to the text
        for item in self.notes:
            self.text += "\n"
            self.text += str(item)

        # writing the text to the text file
        self.file.write(self.text)
        # closing the text file
        self.file.close()

        # disabling the stop recording button
        self.stopRecording["state"] = "disabled"
        # enabling the record button
        self.record["state"] = "normal"

            
    def IncreaseOctave(self):
        """
        Increases the octave value

        Parameters:
        self (object): the instance of the GUI program

        Returns:
        None
        """

        # checking to make sure the user has not changed the integer value to a garbage value
        try:
            # increases the octave by one if it is less than 7
            if self.octave.getNumber() < 7:
                self.octave.setNumber(self.octave.getNumber() + 1)
        except:
            self.messageBox(title="ERROR", message="Octave must be between 0 and 7")

    def DecreaseOctave(self):
        """
        Decreases the octave value

        Parameters:
        self (object): the instance of the GUI program

        Returns:
        None
        """

        # checking to make sure the user has not changed the integer value to a garbage value
        try:
            # decreases the octave by one if it is greater than 0
            if self.octave.getNumber() > 0:
                self.octave.setNumber(self.octave.getNumber() - 1)
        except:
            self.messageBox(title="ERROR", message="Octave must be between 0 and 7")
        
# the main method
def main():
    ModulusSoundMachine().mainloop()

# entry point for the program
if __name__ == "__main__":
    main()

